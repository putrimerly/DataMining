from django.apps import AppConfig


class SimilarityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'similarity'
